установка node js
https://nodejs.org/en/download/

установить gulp
в терминале обычном или vscode в папке с проектом
npm i gulp
https://www.npmjs.com/package/gulp

копируем папки gulp в папку проекта

в консоле
npm i

запуск gulp в консоле пишем 'gulp' (без скобок)
собрать проект - gulp build

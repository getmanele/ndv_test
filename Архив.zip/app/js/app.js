$(document).ready(function () {
  //   $("body").hide();
});
